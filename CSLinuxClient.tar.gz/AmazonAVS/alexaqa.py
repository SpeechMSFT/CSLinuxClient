from avs_client import AlexaVoiceServiceClient
import threading
import sys

ipath = sys.argv[1]
opath = sys.argv[2]

# ipath = './tests/resources/ask-name16k.wav'
# opath = './oask-name.wav'

print(ipath)
print(opath)

alexa_client = AlexaVoiceServiceClient(
    client_id='amzn1.application-oa2-client.f7c4640de493420e9285bbf54e7fe3e4',
    secret='57858ad67fbf1970dfd9b04169f9f9c6da22df2b0d1fc98b2a1c6c3a6efc619e',
    refresh_token='Atzr|IwEBINt1wSg3bwL3D04aUPl0TzQ_fLJJVWV8xojxa4h5UP9wU9CGHgt5p6RE-BNvA-AHcQR2cjzGn2eG4L9OuTZkOXeF9VgRfdTgIm6PTYn6rrkO-YZANoggO_4IJMqwLaKy5WIbynjwpTUJNORhlCORSpFbuyaZ7WefQ-fCyDtwDVF4eB-TZZ4D4fjzunC2xd6xK3Y8wg38uOsWIiX8Lr9uUjFGEW1zK58rbT4L7zQ5R0CDMug5ix1Hsqs5TtQTeZje2gpR28KOYG5H6doh1ZfDUUYttbk6k9EpoeB1n9EXBvRslcWG6duVrHRm6Q0WBOmSBMpdzfz__5ugYqwaYNq7tlbe832o_ffE07eiJxIp9L1ADvKlmxLSykA4iUzrNRaZKT2BP_MUD967DBlN0S2f4HlrGOndAHEpLt0E04VJ77xmDlGdVpPb3P_mFQvY87LzEHq83h651k8VpMeHJiKSIaXllaWvh3WX1WnyO5fD3NnMBCJurfh_1xVqOyojie5N6HqU_5I9j1GE5Fncre-LXBla',
)

# def ping_avs():
#     while True:
#         alexa_client.conditional_ping()
#
# ping_thread = threading.Thread(target=ping_avs)
# ping_thread.start()

alexa_client.connect()  # authenticate and other handshaking steps
with open(ipath, 'rb') as f:
    alexa_response_audio = alexa_client.send_audio_file(f)
with open(opath, 'wb') as f:
    f.write(alexa_response_audio)
