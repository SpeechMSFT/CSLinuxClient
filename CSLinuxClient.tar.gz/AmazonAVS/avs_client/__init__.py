from avs_client.avs_client.client import AlexaVoiceServiceClient


__all__ = [
    'AlexaVoiceServiceClient'
]
