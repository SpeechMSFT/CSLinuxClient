#!/bin/bash
twine upload dist/*
